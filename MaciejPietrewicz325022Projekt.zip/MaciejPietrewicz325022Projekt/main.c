
#include <stdio.h>
#include <stdbool.h>
#include "Game.h"

int main(int argc, char* args[])
{
	initWindow();
	startMenu();
	exitGame();
	
	return 0;
}